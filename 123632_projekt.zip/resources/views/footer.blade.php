<footer class="text-center">
    <div class="container">
        <div class="row row-cols-1 row-cols-lg-3">
            <div class="col">
                <p class="text-muted my-2">Copyright © 2023 KD123632</p>
        </div>
    </div>
</footer>
